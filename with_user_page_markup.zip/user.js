const loadUserInfo = async () => {

};

loadUserInfo();